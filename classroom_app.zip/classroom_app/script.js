// Local Storage Helpers
const save = (key, data) => localStorage.setItem(key, JSON.stringify(data));
const load = (key) => JSON.parse(localStorage.getItem(key)) || [];

// Tasks
let tasks = load("tasks");

function renderTasks() {
  const list = document.getElementById("task-list");
  list.innerHTML = "";
  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <input type="checkbox" ${task.done ? "checked" : ""} onclick="toggleTask(${index})">
      <span style="text-decoration:${task.done ? "line-through" : "none"}">${task.text}</span>
      <button onclick="deleteTask(${index})">🗑️</button>
    `;
    list.appendChild(li);
  });
  save("tasks", tasks);
}

function addTask() {
  const input = document.getElementById("new-task");
  if (input.value.trim()) {
    tasks.push({ text: input.value.trim(), done: false });
    input.value = "";
    renderTasks();
  }
}

function toggleTask(index) {
  tasks[index].done = !tasks[index].done;
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  renderTasks();
}

// Announcements
let announcements = load("announcements");

function renderAnnouncements() {
  const container = document.getElementById("announcement-list");
  container.innerHTML = "";
  announcements.forEach((msg, index) => {
    const div = document.createElement("div");
    div.className = "announcement";
    div.innerHTML = `${msg} <button onclick="deleteAnnouncement(${index})">❌</button>`;
    container.appendChild(div);
  });
  save("announcements", announcements);
}

function addAnnouncement() {
  const input = document.getElementById("new-announcement");
  if (input.value.trim()) {
    announcements.push(input.value.trim());
    input.value = "";
    renderAnnouncements();
  }
}

function deleteAnnouncement(index) {
  announcements.splice(index, 1);
  renderAnnouncements();
}

// Initial render
renderTasks();
renderAnnouncements();

// script.js

// Handle navigation between pages
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  document.getElementById(pageId).classList.add('active');
}

// Add a new assignment
function addTask() {
  const taskInput = document.getElementById('new-task');
  const taskText = taskInput.value.trim();
  if (taskText === '') return;

  const li = document.createElement('li');
  li.innerHTML = `${taskText} <button onclick="removeTask(this)">❌</button>`;
  document.getElementById('task-list').appendChild(li);

  taskInput.value = '';
}

// Remove assignment
function removeTask(button) {
  button.parentElement.remove();
}

// Add a new announcement
function addAnnouncement() {
  const announcementInput = document.getElementById('new-announcement');
  const text = announcementInput.value.trim();
  if (text === '') return;

  const div = document.createElement('div');
  div.className = 'announcement';
  div.textContent = text;
  document.getElementById('announcement-list').appendChild(div);

  announcementInput.value = '';
}

// Update student profile
function updateProfile(event) {
  event.preventDefault();

  const name = document.getElementById('edit-name').value.trim();
  const grade = document.getElementById('edit-grade').value.trim();

  if (name && grade) {
    document.getElementById('student-name').textContent = name;
    document.getElementById('student-grade').textContent = grade;

    showPage('profile');
  }
}

// Update dashboard summary counts and student info
function updateDashboard() {
  const name = document.getElementById('student-name').textContent;
  const grade = document.getElementById('student-grade').textContent;
  const assignments = document.querySelectorAll('#task-list li').length;
  const announcements = document.querySelectorAll('#announcement-list .announcement').length;

  document.getElementById('dashboard-name').textContent = name;
  document.getElementById('dashboard-grade').textContent = grade;
  document.getElementById('assignment-count').textContent = assignments;
  document.getElementById('announcement-count').textContent = announcements;
}

// Call this whenever a task or announcement is added/removed
function refreshData() {
  updateDashboard();
}

// Call refreshData inside existing functions
function addTask() {
  const taskInput = document.getElementById('new-task');
  const taskText = taskInput.value.trim();
  if (taskText === '') return;

  const li = document.createElement('li');
  li.innerHTML = `${taskText} <button onclick="removeTask(this)">❌</button>`;
  document.getElementById('task-list').appendChild(li);

  taskInput.value = '';
  refreshData();
}

function removeTask(button) {
  button.parentElement.remove();
  refreshData();
}

function addAnnouncement() {
  const announcementInput = document.getElementById('new-announcement');
  const text = announcementInput.value.trim();
  if (text === '') return;

  const div = document.createElement('div');
  div.className = 'announcement';
  div.textContent = text;
  document.getElementById('announcement-list').appendChild(div);

  announcementInput.value = '';
  refreshData();
}

function updateProfile(event) {
  event.preventDefault();

  const name = document.getElementById('edit-name').value.trim();
  const grade = document.getElementById('edit-grade').value.trim();

  if (name && grade) {
    document.getElementById('student-name').textContent = name;
    document.getElementById('student-grade').textContent = grade;
    refreshData();
    showPage('profile');
  }
}

// Call on load
window.onload = () => {
  refreshData();
};
``
